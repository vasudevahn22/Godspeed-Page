import React from 'react';
import { CheckCircle, Activity, Users, Globe } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Why Godspeed?
            </h2>
            <p className="text-lg text-gray-700 mb-8">
              At Godspeed, we envision a future where founders and startups thrive in the post-AI era through collaboration and innovation —driving progress and making the world a better place. We democratize product development by continuously evolving our technology and AI infrastructure, fostering a collaborative ecosystem that connects founders, investors and experts to drive mutual growth.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-6 rounded-xl">
                <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <Activity className="text-indigo-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">5x Faster</h3>
                <p className="text-gray-700">
                  Build and deploy production-ready backends up to 5x faster than traditional development.
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-xl">
                <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="text-indigo-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Enterprise Ready</h3>
                <p className="text-gray-700">
                  Built-in security, scalability, and monitoring for enterprise applications.
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-xl">
                <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <CheckCircle className="text-indigo-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Best Practices</h3>
                <p className="text-gray-700">
                  Automatically implement development best practices and patterns.
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-xl">
                <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <Globe className="text-indigo-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Full Control</h3>
                <p className="text-gray-700">
                  Maintain complete control over your code and infrastructure.
                </p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500 to-blue-500 rounded-2xl blur-xl opacity-20 transform rotate-3"></div>
            <div className="relative overflow-hidden rounded-2xl">
              <div className="aspect-w-16 aspect-h-9">
                <img 
                  src="https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Development team collaboration" 
                  className="object-cover w-full h-full rounded-2xl"
                />
              </div>
              
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-indigo-900 to-transparent p-8">
                <div className="max-w-md">
                  <blockquote className="text-white text-lg italic">
                    "Godspeed has transformed how we build our backend services. What used to take weeks now takes days."
                  </blockquote>
                  <cite className="text-indigo-200 block mt-4">
                    — Engineering Lead at Enterprise Co.
                  </cite>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-24">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These principles guide our platform development and shape how we help teams build better software.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Developer Experience",
                description: "We prioritize creating tools that developers love to use, making the development process enjoyable and productive."
              },
              {
                title: "Enterprise Grade",
                description: "Built for scale with security, performance, and reliability at its core. Ready for mission-critical applications."
              },
              {
                title: "Future Ready",
                description: "Constantly evolving with modern development practices and emerging technologies to keep your stack current."
              }
            ].map((value, idx) => (
              <div key={idx} className="bg-gradient-to-br from-gray-50 to-white p-8 rounded-xl shadow-sm border border-gray-100">
                <div className="h-12 w-12 bg-indigo-100 rounded-full flex items-center justify-center mb-6">
                  <span className="text-2xl font-bold text-indigo-600">0{idx + 1}</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{value.title}</h3>
                <p className="text-gray-700">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;