import React from 'react';
import { Check } from 'lucide-react';

interface PricingCardProps {
  name: string;
  price: number;
  description: string;
  features: string[];
  popular?: boolean;
  buttonText: string;
  buttonVariant: 'primary' | 'secondary';
  isAnnual: boolean;
}

const PricingCard: React.FC<PricingCardProps> = ({
  name,
  price,
  description,
  features,
  popular = false,
  buttonText,
  buttonVariant,
  isAnnual
}) => {
  return (
    <div 
      className={`rounded-2xl overflow-hidden transition-all duration-300 ${
        popular 
          ? 'shadow-xl border-2 border-indigo-500 transform hover:-translate-y-1' 
          : 'shadow-md border border-gray-100 hover:shadow-lg'
      }`}
    >
      {popular && (
        <div className="bg-indigo-500 py-2 text-center text-white text-sm font-medium">
          Most Popular
        </div>
      )}
      
      <div className={`p-8 bg-white ${!popular && 'pt-10'}`}>
        <h3 className="text-xl font-bold text-gray-900 mb-2">{name}</h3>
        <p className="text-gray-600 mb-6">{description}</p>
        
        <div className="mb-6">
          <div className="flex items-end mb-2">
            <span className="text-4xl font-bold text-gray-900">${price}</span>
            <span className="text-gray-600 ml-2 mb-1">/mo</span>
          </div>
          {isAnnual && (
            <span className="text-sm text-indigo-600 font-medium">
              Billed annually
            </span>
          )}
        </div>
        
        <ul className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="text-green-500 mt-0.5 mr-3 flex-shrink-0" size={18} />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
        
        <button
          className={`w-full py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
            buttonVariant === 'primary'
              ? 'bg-indigo-600 text-white hover:bg-indigo-700'
              : 'bg-white border border-gray-200 text-gray-800 hover:bg-gray-50'
          }`}
        >
          {buttonText}
        </button>
      </div>
    </div>
  );
};

export default PricingCard;