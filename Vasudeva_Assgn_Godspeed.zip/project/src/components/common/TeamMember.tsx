import React from 'react';
import { Twitter, Linkedin, Github as GitHub } from 'lucide-react';

interface TeamMemberProps {
  name: string;
  role: string;
  bio: string;
  image: string;
  socialLinks: {
    twitter?: string;
    linkedin?: string;
    github?: string;
  };
}

const TeamMember: React.FC<TeamMemberProps> = ({ name, role, bio, image, socialLinks }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow group">
      <div className="h-64 overflow-hidden">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900">{name}</h3>
        <p className="text-indigo-600 font-medium mb-3">{role}</p>
        <p className="text-gray-600 mb-4">{bio}</p>
        
        <div className="flex space-x-4">
          {socialLinks.twitter && (
            <a 
              href={socialLinks.twitter} 
              className="text-gray-400 hover:text-indigo-600 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Twitter size={18} />
            </a>
          )}
          
          {socialLinks.linkedin && (
            <a 
              href={socialLinks.linkedin} 
              className="text-gray-400 hover:text-indigo-600 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Linkedin size={18} />
            </a>
          )}
          
          {socialLinks.github && (
            <a 
              href={socialLinks.github} 
              className="text-gray-400 hover:text-indigo-600 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <GitHub size={18} />
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default TeamMember;