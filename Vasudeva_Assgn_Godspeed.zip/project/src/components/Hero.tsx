import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section 
      id="home" 
      className="relative min-h-screen flex items-center pt-16 bg-gradient-to-br from-indigo-900 via-blue-900 to-indigo-800 text-white overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-indigo-500 opacity-20 rounded-full blur-3xl"></div>
        <div className="absolute top-1/4 -left-20 w-72 h-72 bg-blue-400 opacity-20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-purple-500 opacity-10 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6 z-10 py-12 md:py-24">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 mb-10 md:mb-0">
            <span className="inline-block px-4 py-2 rounded-full bg-indigo-700 bg-opacity-50 text-sm font-medium mb-4">
              Build Better, Build Faster
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              The Modern Backend <span className="text-indigo-400">Development Platform</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-xl">
              Build scalable backends in minutes with our low-code platform. Godspeed accelerates development with built-in best practices and enterprise-grade security.
            </p>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <a 
                href="#product" 
                className="px-8 py-3 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition-all duration-200 transform hover:translate-y-[-2px] hover:shadow-lg inline-flex items-center"
              >
                Get Started
                <ArrowRight size={18} className="ml-2" />
              </a>
              <a 
                href="https://docs.godspeed.systems"
                target="_blank"
                rel="noopener noreferrer" 
                className="px-8 py-3 rounded-lg bg-transparent border border-white text-white font-medium hover:bg-white hover:bg-opacity-10 transition-all duration-200 transform hover:translate-y-[-2px]"
              >
                Documentation
              </a>
            </div>
          </div>
          
          <div className="w-full md:w-1/2">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-indigo-600 to-purple-500 rounded-2xl blur-2xl opacity-30 transform -rotate-6"></div>
              <div className="relative bg-gray-900 border border-gray-800 rounded-xl shadow-2xl overflow-hidden">
                <div className="flex bg-gray-800 px-4 py-2">
                  <div className="flex space-x-2">
                    <div className="h-3 w-3 rounded-full bg-red-500"></div>
                    <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                    <div className="h-3 w-3 rounded-full bg-green-500"></div>
                  </div>
                </div>
                <div className="p-4 text-sm text-gray-300 font-mono">
                  <p className="opacity-70">
                    <span className="text-blue-400">$</span> npx create-godspeed-app my-app
                  </p>
                  <p className="text-green-400 mt-2">
                    ✓ Project initialized successfully
                  </p>
                  <p className="opacity-70 mt-2">
                    <span className="text-blue-400">$</span> cd my-app && npm run dev
                  </p>
                  <p className="text-green-400 mt-2">
                    ✓ Development server started at http://localhost:3000
                  </p>
                  <p className="mt-2">
                    <span className="text-yellow-400">➤</span> Building with Godspeed...
                  </p>
                  <p className="text-green-400 mt-2">
                    ✓ API endpoints generated
                  </p>
                  <p className="text-blue-400 mt-2 animate-pulse">
                    Ready for development!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
};

export default Hero;