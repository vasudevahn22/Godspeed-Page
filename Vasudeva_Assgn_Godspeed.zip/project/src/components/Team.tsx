import React from 'react';
import TeamMember from './common/TeamMember';

const teamMembers = [
  {
    name: 'Ayush Ghai',
    role: 'Chief Alchemist',
    bio: 'An IIT-Kanpur alumnus, techie and serial founder, Ayush serves as a motivational speaker, life coach and startup coach, driven by a mission to build a better future through community and social impact initiatives.',
    image: 'https://media.licdn.com/dms/image/v2/D5603AQEReUupNLC_Cw/profile-displayphoto-shrink_400_400/profile-displayphoto-shrink_400_400/0/1679077553521?e=1752710400&v=beta&t=IF-nf97o0mqrGrET4561ruZkYYDF0NoLv9Wijaxqhdc',
    socialLinks: {
      twitter: 'https://twitter.com',
      linkedin: 'https://linkedin.com',
      github: 'https://github.com'
    }
  },
  {
    name: 'Akshar Ghai',
    role: 'Backstage Brain',
    bio: 'As CEO of Almamet India, where he established and scaled the company to profitability, he provides invaluable behind-the-scenes strategic advisory on core business aspects at Godspeed.',
    image: 'https://www.godspeed.systems/files/aksharGhaiPic2.jpeg',
    socialLinks: {
      twitter: 'https://twitter.com',
      linkedin: 'https://linkedin.com',
      github: 'https://github.com'
    }
  },
  {
    name: 'Alexander Rhomberg',
    role: 'Angel with a chequebook',
    bio: 'Alexander Rhomberg, co-founder of Almamet GMBH, brings 40 years of experience building and scaling multinational businesses to his role as angel investor and advisor of Godspeed',
    image: 'https://www.godspeed.systems/files/alexander1.JPG',
    socialLinks: {
      twitter: 'https://twitter.com',
      linkedin: 'https://linkedin.com',
      github: 'https://github.com'
    }
  },
  
  {
    name: 'Dharuv Manchanda',
    role: 'Full Stack Hustler',
    bio: 'For Dharuv, coding is not just a job—it is a passion. This budding full-stack developer rings energy and enthusiasm to every project.',
    image: 'https://www.godspeed.systems/files/dharuv.jpeg',
    socialLinks: {
      twitter: 'https://twitter.com',
      linkedin: 'https://linkedin.com',
      github: 'https://github.com'
    }
  }
];

const Team: React.FC = () => {
  return (
    <section id="team" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Meet Our Team
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            The brilliant minds behind Godspeed are passionate about creating 
            tools that empower developers to build exceptional applications.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <TeamMember
              key={index}
              name={member.name}
              role={member.role}
              bio={member.bio}
              image={member.image}
              socialLinks={member.socialLinks}
            />
          ))}
        </div>

        <div className="mt-20 bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 md:p-12 lg:p-16">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">
                Join Our Team
              </h3>
              <p className="text-gray-700 mb-8">
                We're always looking for talented individuals who are passionate about 
                creating tools that empower developers and accelerate the development process.
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <div className="h-2 w-2 rounded-full bg-indigo-500 mr-3"></div>
                  <p className="text-gray-700">Competitive salary and equity packages</p>
                </div>
                <div className="flex items-center">
                  <div className="h-2 w-2 rounded-full bg-indigo-500 mr-3"></div>
                  <p className="text-gray-700">Remote-first with flexible working hours</p>
                </div>
                <div className="flex items-center">
                  <div className="h-2 w-2 rounded-full bg-indigo-500 mr-3"></div>
                  <p className="text-gray-700">Health, dental, and vision insurance</p>
                </div>
                <div className="flex items-center">
                  <div className="h-2 w-2 rounded-full bg-indigo-500 mr-3"></div>
                  <p className="text-gray-700">Professional development budget</p>
                </div>
              </div>
              
              <a 
                href="#careers" 
                className="px-8 py-3 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition-all duration-200 inline-block"
              >
                View Open Positions
              </a>
            </div>
            <div 
              className="h-64 lg:h-auto bg-cover bg-center" 
              style={{ backgroundImage: "url('https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')" }}
            ></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;