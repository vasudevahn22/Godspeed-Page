import React from 'react';
import { Zap, Code, Layers, ShieldCheck, RefreshCw, Database } from 'lucide-react';
import FeatureCard from './common/FeatureCard';

const features = [
  {
    icon: <Zap className="text-indigo-500" size={24} />,
    title: 'Rapid Development',
    description: 'Build production-ready backends in minutes with our intuitive low-code platform and pre-built components.'
  },
  {
    icon: <Database className="text-indigo-500" size={24} />,
    title: 'Data Modeling',
    description: 'Define your data model and relationships with our visual designer. Automatic migration handling and versioning.'
  },
  {
    icon: <Layers className="text-indigo-500" size={24} />,
    title: 'API Generation',
    description: 'Automatically generate RESTful and GraphQL APIs from your data models with built-in validation and documentation.'
  },
  {
    icon: <ShieldCheck className="text-indigo-500" size={24} />,
    title: 'Enterprise Security',
    description: 'Built-in authentication, authorization, and security best practices to keep your applications protected.'
  },
  {
    icon: <Code className="text-indigo-500" size={24} />,
    title: 'Custom Logic',
    description: 'Write custom business logic in TypeScript or JavaScript. Full access to Node.js ecosystem.'
  },
  {
    icon: <RefreshCw className="text-indigo-500" size={24} />,
    title: 'Real-time Updates',
    description: 'Built-in WebSocket support for real-time features. Automatic scaling and connection management.'
  }
];

const Product: React.FC = () => {
  return (
    <section id="product" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Modern Backend Development
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Godspeed provides everything you need to build scalable, secure, and maintainable 
            backend applications without the traditional development overhead.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>

        <div className="mt-20">
          <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-3xl overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="p-8 md:p-12 lg:p-16">
                <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">
                  Development Made Simple
                </h3>
                <p className="text-gray-700 mb-6">
                  Godspeed's modern approach to backend development combines the flexibility of 
                  code with the speed of low-code platforms, helping teams ship faster while 
                  maintaining best practices.
                </p>
                
                <div className="space-y-4">
                  {[
                    { number: "01", title: "Model", text: "Define your data models and relationships visually or in code." },
                    { number: "02", title: "Configure", text: "Set up authentication, permissions, and business logic." },
                    { number: "03", title: "Generate", text: "Auto-generate APIs, documentation, and type definitions." },
                    { number: "04", title: "Deploy", text: "One-click deployment to your infrastructure of choice." }
                  ].map((step, idx) => (
                    <div key={idx} className="flex">
                      <div className="flex-shrink-0 mr-4">
                        <span className="flex items-center justify-center h-10 w-10 rounded-full bg-indigo-100 text-indigo-600 font-semibold">
                          {step.number}
                        </span>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{step.title}</h4>
                        <p className="text-gray-600">{step.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="relative h-full lg:h-[500px] bg-indigo-900 overflow-hidden">
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute top-0 left-0 right-0 h-48 bg-gradient-to-b from-indigo-600 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-indigo-800 to-transparent"></div>
                </div>
                <div className="relative h-full flex items-center justify-center p-8">
                  <div className="bg-gray-900 rounded-xl shadow-2xl overflow-hidden max-w-md w-full">
                    <div className="flex bg-gray-800 px-4 py-2">
                      <div className="flex space-x-2">
                        <div className="h-3 w-3 rounded-full bg-red-500"></div>
                        <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                        <div className="h-3 w-3 rounded-full bg-green-500"></div>
                      </div>
                    </div>
                    <div className="p-4 text-sm font-mono text-gray-300">
                      <div className="mb-2 text-blue-400">// Define your API routes</div>
                      <div className="text-pink-400">import</div>
                      <div className="text-white"> &#123; createAPI &#125; </div>
                      <div className="text-pink-400">from</div>
                      <div className="text-green-400"> '@godspeed/core';</div>
                      <div className="mt-2">
                        <div className="text-pink-400">const</div>
                        <div className="text-white"> api = </div>
                        <div className="text-yellow-400">createAPI</div>
                        <div className="text-white">();</div>
                      </div>
                      <div className="mt-2">
                        <div className="text-white">api.</div>
                        <div className="text-yellow-400">post</div>
                        <div className="text-white">(</div>
                        <div className="text-green-400">'/users'</div>
                        <div className="text-white">, async (req, res) =&gt; &#123;</div>
                      </div>
                      <div className="ml-4 text-white">
                        <div className="text-pink-400">const</div> user = 
                        <div className="text-pink-400">await</div> db.users.create(req.body);
                        <div className="text-pink-400">return</div> res.json(user);
                      </div>
                      <div className="text-white">&#125;);</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Product;