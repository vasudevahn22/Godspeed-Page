import React, { useState } from 'react';
import { Check } from 'lucide-react';
import PricingCard from './common/PricingCard';

const plans = [
  {
    name: 'Starter',
    price: {
      monthly: 0,
      annually: 0
    },
    description: 'Perfect for individuals and small projects.',
    features: [
      '3 projects',
      'Up to 10,000 builds per month',
      'Community support',
      'Basic analytics',
      'Standard security'
    ],
    popular: false,
    buttonText: 'Get Started Free',
    buttonVariant: 'secondary'
  },
  {
    name: 'Pro',
    price: {
      monthly: 29,
      annually: 25
    },
    description: 'Ideal for professionals and growing teams.',
    features: [
      'Unlimited projects',
      'Up to 100,000 builds per month',
      'Priority support',
      'Advanced analytics',
      'Enhanced security',
      'Custom domains',
      'Team collaboration tools'
    ],
    popular: true,
    buttonText: 'Subscribe to Pro',
    buttonVariant: 'primary'
  },
  {
    name: 'Enterprise',
    price: {
      monthly: 99,
      annually: 89
    },
    description: 'For large-scale operations and organizations.',
    features: [
      'Unlimited everything',
      'Dedicated support',
      'Custom integrations',
      'SLA guarantees',
      'Advanced security controls',
      'SSO integration',
      'Audit logs and compliance',
      'Dedicated infrastructure'
    ],
    popular: false,
    buttonText: 'Contact Sales',
    buttonVariant: 'secondary'
  }
];

const Pricing: React.FC = () => {
  const [isAnnual, setIsAnnual] = useState(true);

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose the perfect plan for your needs. All plans include core features 
            with different limits and capabilities.
          </p>
          
          <div className="mt-8 inline-flex items-center p-1 bg-gray-100 rounded-lg">
            <button
              className={`px-4 py-2 rounded-md transition-all ${
                !isAnnual
                  ? 'bg-white shadow-sm text-gray-900'
                  : 'bg-transparent text-gray-600'
              }`}
              onClick={() => setIsAnnual(false)}
            >
              Monthly
            </button>
            <button
              className={`px-4 py-2 rounded-md transition-all ${
                isAnnual
                  ? 'bg-white shadow-sm text-gray-900'
                  : 'bg-transparent text-gray-600'
              }`}
              onClick={() => setIsAnnual(true)}
            >
              Annually <span className="text-xs text-indigo-600 font-semibold">Save 15%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <PricingCard
              key={index}
              name={plan.name}
              price={isAnnual ? plan.price.annually : plan.price.monthly}
              description={plan.description}
              features={plan.features}
              popular={plan.popular}
              buttonText={plan.buttonText}
              buttonVariant={plan.buttonVariant}
              isAnnual={isAnnual}
            />
          ))}
        </div>

        <div className="mt-20 bg-white rounded-2xl overflow-hidden shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 md:p-12 lg:p-16">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">
                Frequently Asked Questions
              </h3>
              
              <div className="space-y-8">
                {[
                  {
                    question: "Can I switch plans later?",
                    answer: "Yes, you can upgrade or downgrade your plan at any time. Any changes will be prorated for your billing cycle."
                  },
                  {
                    question: "Is there a free trial?",
                    answer: "Our Starter plan is free forever with generous limits. For Pro and Enterprise plans, we offer a 14-day free trial with no credit card required."
                  },
                  {
                    question: "What payment methods do you accept?",
                    answer: "We accept all major credit cards, PayPal, and for Enterprise customers, we can arrange invoicing."
                  },
                  {
                    question: "Can I get a refund if I'm not satisfied?",
                    answer: "Yes, we offer a 30-day money-back guarantee if you're not completely satisfied with your purchase."
                  }
                ].map((faq, idx) => (
                  <div key={idx}>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h4>
                    <p className="text-gray-700">{faq.answer}</p>
                  </div>
                ))}
              </div>
              
              <div className="mt-10 pt-8 border-t border-gray-100">
                <p className="text-gray-600">
                  Need more information? <a href="#contact" className="text-indigo-600 hover:text-indigo-800 font-medium">Contact our sales team</a>
                </p>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-indigo-500 to-blue-600 p-8 md:p-12 lg:p-16 text-white">
              <h3 className="text-2xl font-bold mb-6">Enterprise Solutions</h3>
              <p className="mb-8">
                Need a custom solution for your organization? Our enterprise plans offer advanced features, 
                dedicated support, and custom integrations tailored to your needs.
              </p>
              
              <div className="space-y-4 mb-8">
                {[
                  "Dedicated account manager",
                  "Custom SLAs and support",
                  "Advanced security features",
                  "On-premise deployment options",
                  "Custom integrations",
                  "Training and onboarding"
                ].map((feature, idx) => (
                  <div key={idx} className="flex items-start">
                    <Check className="text-white mt-1 mr-3 flex-shrink-0" size={18} />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
              
              <a 
                href="#contact" 
                className="px-8 py-3 rounded-lg bg-white text-indigo-600 font-medium hover:bg-gray-100 transition-all duration-200 inline-block"
              >
                Contact Our Sales Team
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;