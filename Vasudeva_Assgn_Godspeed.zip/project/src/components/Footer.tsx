import React from 'react';
import { Twitter, Linkedin, Facebook, Instagram, Github as GitHub } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="mb-6">
              <h3 className="text-2xl font-bold text-white">Godspeed</h3>
              <p className="text-gray-400 mt-2">Build at the speed of light</p>
            </div>
            <p className="text-gray-400 mb-6">
              Revolutionizing development with our lightning-fast tools and intuitive platform.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <GitHub size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Product</h4>
            <ul className="space-y-4">
              {['Features', 'Pricing', 'Roadmap', 'Changelog', 'Documentation', 'API'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Company</h4>
            <ul className="space-y-4">
              {['About', 'Team', 'Careers', 'Press', 'Partners', 'Legal'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Contact</h4>
            <ul className="space-y-4">
              <li className="text-gray-400">
                <span className="block">Email</span>
                <a href="mailto:contact@godspeed.systems" className="text-indigo-400 hover:text-indigo-300">
                  contact@godspeed.systems
                </a>
              </li>
              <li className="text-gray-400">
                <span className="block">Address</span>
                <address className="not-italic">
                  Dharamshala<br />
                  Himachal Pradesh, India
                </address>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 text-center md:flex md:justify-between md:text-left">
          <p className="text-gray-500 mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} 2024 by ISHGATI TECHNOLOGIES PRIVATE LIMITED
          </p>
          <ul className="flex space-x-6 justify-center md:justify-start">
            {['Terms', 'Privacy', 'Cookies', 'Accessibility'].map((item) => (
              <li key={item}>
                <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors">
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
};

export default Footer;