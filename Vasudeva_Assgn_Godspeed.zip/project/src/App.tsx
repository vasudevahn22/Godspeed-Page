import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Product from './components/Product';
import Team from './components/Team';
import About from './components/About';
import Pricing from './components/Pricing';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Product />
      <Team />
      <About />
      <Pricing />
      <Footer />
      <ScrollToTop />
    </div>
  );
}

export default App;